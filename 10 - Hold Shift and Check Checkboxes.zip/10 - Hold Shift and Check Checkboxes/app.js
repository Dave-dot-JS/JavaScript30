// Set up query selectors
const items = document.querySelectorAll('input');
const itemArray = Array.from(items);

// Set up an array to store the items that are checked
let lastChecked;
let isChecked = [];

// Set up event listener to trigger shift+click event
itemArray.forEach(item => {
	item.addEventListener('click', (e) => {
		if (e.shiftKey) {  // Only execute checkBetween() if the shift key is being held down
			isChecked = [];
			e.target.checked = true;
			setChecked();
			checkBetween();
		};
	});
});


// Generate array of checked boxes
function setChecked() {
	for (var i = 0; i < items.length; i++) {
		if (items[i].checked == true) {
			isChecked.push(i);
		}
	}
}

// Trigger checking of boxes between last checked and current checked
function checkBetween() {
	for (var j = isChecked[0]; j < isChecked[isChecked.length - 1]; j++) {
		items[j].checked = true;
	}
}