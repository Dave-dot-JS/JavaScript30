// Set up variables
const items = document.querySelectorAll('.inbox input[type="checkbox"]');

let lastChecked;

// Set up functions
function checkAll(e) {
	let inBetween = false;
	if (e.shiftKey && this.checked) {  // Only execute checkBetween() if the shift key is being held down
		items.forEach(item => {
			if (item === this || item === lastChecked) {
				inBetween = !inBetween;
			}
			if (inBetween) {
				item.checked = true;
			}
		});
	}
	lastChecked = this;
}

// Set up event listeners
items.forEach(item => item.addEventListener('click', checkAll));
